package com.dl.tool;

import com.alibaba.fastjson.JSONObject;
import org.apache.logging.log4j.LogManager;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Desc:系统初始化读取
 * Created by xx on 2019/12/24.
 */
public class AnaUtil  {
    
    private static final org.apache.logging.log4j.Logger logger = LogManager.getLogger(AnaUtil.class);
    public static JSONObject objana = new JSONObject();



   /* static{
        loadAna(jdbcTemplate);
    }*/

    synchronized static public void loadAna(JdbcTemplate jdbcTemplate){
        logger.info("开始读取ana内容.......");



        int i,j,maxsav=0,maxdnsav=0;

        i=0;j=0;
        Map<String,Object> map =null;//new HashMap<>();// (HashMap)userData.get(i);
        String sql="select * from prtuana_v ";

        //if(rand.equalsIgnoreCase(imagerand)){
        try{
            List<Map<String, Object>> userData = jdbcTemplate.queryForList(sql);
            int size=userData.size() ;
            if (size> 0)
            {

                for ( i = 0; i<size; i++)
                {

                    map = (HashMap) userData.get(i);

                    maxsav=(Integer.parseInt(map.get("saveno").toString())>maxsav?Integer.parseInt(map.get("saveno").toString()):maxsav);
                    try
                    {
                        maxdnsav=(Integer.parseInt(map.get("pulsaveno").toString())>maxdnsav?Integer.parseInt(map.get("pulsaveno").toString()):maxdnsav);
                    }
                    catch(Exception e)
                    {}
                    objana.put(map.get("kkey").toString(),map);

                }
                objana.put("maxsav",maxsav);
                objana.put("maxdnsav",maxdnsav);
            }

        }catch(Exception e){
            logger.warn("出错了"+e.toString());
        }
        //logger.warn(objana);
        logger.warn(objana.toJSONString());
        logger.info("加载ana内容完成...........");

    }


}