 package com.dl.tool;

/**
 *@class_name：Timeer
 *@comments:
 *@param:
 *@return: 
 *@author:xx
 *@createtime:2019-1-8
 */
 import java.sql.SQLException;

 import com.dl.quartz.LuaJob;


 import java.sql.PreparedStatement;
import java.sql.ResultSet;
 import java.util.ArrayList;
 import java.util.HashMap;
import java.util.List;
import java.util.Map;

 import com.dl.quartz.QuartzJob;
 import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;




import com.alibaba.fastjson.JSONObject;
import com.bjsxt.thread.*;
import com.mysql.jdbc.ResultSetMetaData;

 import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;


 public class Timeer  implements ServletContextListener {
	
	//private ThreadTimer T1 = null; //原定时任务（cmd发送命令给周），现已停用
	//private ThreadLua T2 = null;    //定时执行lua脚本。定时任务统一放在本线程中添加，包含：定时开关机，定时执行lua脚本，5分钟存储历史遥测、历史电量数据
	private ThreadDemo T3 = null;     //定期取得实时数据，发送给http客户端，判断遥信变位和遥测越限（以及恢复），并存入Mysql库
	private ThreadSubscriber T4 = null; //监听redis库，取得变化遥测遥信数据，并发送给http客户端
	private DelayWork T5 = null;   //定期检查redis库中是否有延时任务
	
	DBConnection dbcon=null;
	PreparedStatement pstmt=null;
	ResultSet rs;
	private static  JSONObject taskarray = new JSONObject();  
	  private static final Logger logger = LogManager.getLogger(Timeer.class);
     public Timeer() {
     
    	 
    	 dbcon = new DBConnection();
    	 
     }
     
    
    
	/* (non-Javadoc)
	 * <p>Title: contextDestroyed</p>  
	 * <p>Description: </p>  
	 * @param arg0  
	 * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)  
	 */
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	 public void log(Object msg)
	  {
	    System.out.println(msg);
	  }
	/* (non-Javadoc)
	 * <p>Title: contextInitialized</p>  
	 * <p>Description: </p>  
	 * @param arg0  
	 * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)  
	 */
	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		// TODO Auto-generated method stub
		
		
		// T1 = new ThreadTimer("timer");
				 //   T1.start();
		//static
	
		List<Map<String, Object>> taskstr = null;
		int id0=0,id1=0;
		
		String sql="select * from timetask_detial order by taskid,id";
		
		List<Map<String, Object>> tasktype1 = new ArrayList<Map<String, Object>>();
		//List<Map<String, Object>> tasktype2 = new ArrayList<Map<String, Object>>();
			try{
				pstmt=dbcon.setPreparedStatement(sql);
				
				rs=dbcon.getPrepatedResultSet();
				 // json数组  
				   ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();  
				   int columnCount = metaData.getColumnCount();  
				    
				   // 遍历ResultSet中的每条数据  
				    while (rs.next()) {  
				       // JSONObject jsonObj = new JSONObject(); 
				    	id0=rs.getInt("taskid");
				    
			    		
			    		//logger.warn(tasktype1.toString());
				    	if (id0!=id1)
				    	{
				    		List<Map<String, Object>> ttasktype = new ArrayList<Map<String, Object>>();
				    		
				    		for (Map<String, Object> tmap:tasktype1){
				    			ttasktype.add(tmap);
				    		}
			    			//ttasktype = tasktype1;
				    		if (id1!=0)
				    		{
				    			
				    			taskarray.put("taskarry"+id1, ttasktype);
				    			
				    			
				    		}
				    	
				    		tasktype1.clear();
				    		id1=id0;
				    	}
				        Map<String, Object> map = new HashMap<String,Object>(); 
				        // 遍历每一列  
				        for (int i = 1; i <= columnCount; i++) {  
				           // String columnName =metaData.getColumnLabel(i);  
				           // String value = rs.getString(columnName);  
				           // jsonObj.put(columnName, value);  
				        	map.put(metaData.getColumnName(i),rs.getObject(i));
				        }   
				        tasktype1.add(map);   
				        map.clear();
				        map=null;
				      
				    } 
				    taskarray.put("taskarry"+id1, tasktype1);
				    
				    
            // pstmt.close();
            // dbcon.getClose();
			}catch(SQLException e){
				System.out.println("出错了"+e.toString());
			}
		
	
			logger.warn(taskarray.toString());
	
	
	
	
	int i,j;
	i=0;j=0;
	 sql="select * from timetask ";
	//if(rand.equalsIgnoreCase(imagerand)){
		try{
			pstmt=dbcon.setPreparedStatement(sql);
			
			rs=dbcon.getPrepatedResultSet();
			
			while(rs.next()){
				if (taskstr!=null)taskstr.clear();
				i=rs.getInt("id");
				switch (rs.getInt("type")) {
				case 1:
					taskstr = (List<Map<String, Object>>) taskarray.get("taskarry"+i);
					SchedulerUtil.hadleCronTrigger(rs.getString("id"), rs.getString("type"),""+i, ""+j, QuartzJob.class,rs.getString("cronstr"),taskstr);
					break;
				case 2:
					Map<String, Object> map = new HashMap<String,Object>();
					map.put("luaname",rs.getString("luaname"));
					taskstr.add(map) ;
					SchedulerUtil.hadleCronTrigger(rs.getString("id"), rs.getString("type"),""+i, ""+j, LuaJob.class,rs.getString("cronstr"),taskstr);
					break;
				case 3:	
					SchedulerUtil.hadleCronTrigger("1","2","3","4",saveHistyc.class,rs.getString("cronstr"),taskstr);
					break;
				default:
					break;
				}
				
				//logger.warn(taskstr);
				
				i++;
				j++;
			}
         pstmt.close();
         dbcon.getClose();
		}catch(SQLException e){
			System.out.println("出错了"+e.toString());
		}
		
		//SchedulerUtil.hadleCronTrigger("1","2","3","4",saveHistyc.class,"0 0,5,10,15,20,25,30,35,40,45,50,55 * * * ? *",taskstr); 	
		
		
		SchedulerUtil.hadleCronTrigger("44032", "3332","44032", "3332",UpdateDataJob.class,"*/1 * * * * ?",taskstr); 	 
		//SchedulerUtil.hadleCronTrigger("44031", "3331","44030", "3330",MyJob.class,"*/3 * * * * ?"); 	 
		    	// T2 = new ThreadLua("lua");
		    			//    T2.start(); 
		   // T3 = new ThreadDemo("ask_data");
		   // T3.start(); 
		    T4 = new ThreadSubscriber("lisner_data");
		    T4.start(); 
		    T5 = new DelayWork("DelayWork");
		    T5.start(); 
		
		
	}
      
    }
