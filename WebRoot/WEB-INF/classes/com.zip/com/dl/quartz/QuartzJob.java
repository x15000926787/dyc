package com.dl.quartz;

import com.dl.tool.RedisUtil;
import net.sf.json.JSONObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.*;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.exceptions.JedisConnectionException;

import java.util.HashMap;

/**
 * [任务类]
 * @author xx
 * @date 2019-8-20 
 * @copyright copyright (c) 2018
 */

@PersistJobDataAfterExecution
@DisallowConcurrentExecution
public  class QuartzJob implements Job {
	   
	    Jedis jedis = null;
	   private static final Logger logger = LogManager.getLogger(QuartzJob.class);
	   String s = null;
	      String vals = null;
	      String keys = null;
	      String luaStr = null;

	     // String pId = FirstClass.projectId;
	  //	DBConnection dbcon=null;//
	  //	PreparedStatement pstmt=null;
		//ResultSet rs;
		
		
		
		public QuartzJob() {
			//static
			//logger.warn("Myjob.jpool:"+jpool.toString());
				//logger.warn(taskarray);
			
		}
		
    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
       //

    	
    	
    	HashMap<String, String> tmap = (HashMap<String, String>) (arg0.getJobDetail().getJobDataMap().get("taskdetial"));
    	/*Map tmap=new HashMap<String, String>();
    	
    	tmap=(Map<String, String>) (arg0.getJobDetail().getJobDataMap().get("taskdetial"));
    	*/
    	String jobtype="1"; 
    	switch (jobtype) {
    	case "1":
		    		try {
		    			
						 jedis = RedisUtil.getJedis();
						// Pipeline p = jedis.pipelined(); 
						 logger.warn(tmap.get("vv").toString());
						 JSONObject jsonObject = JSONObject.fromObject(tmap.get("vv").toString());
						    
					       
					    	
					    	for (Object key:jsonObject.keySet()) {
					    		vals = jsonObject.getString((String) key);   			    			
    			    			jedis.set(key+"_.value",vals);
				        	    jedis.set(key+"_.status","1"); 
					    		logger.warn("执行定时任务:  "+key+"  : "+vals);
    			    		}
				        	
				        	/*for(Map<String, Object> job:tmap)
				        	{
				        		key = job.get("kkey").toString();
				        		vals = job.get("val").toString();
				        		
				        	}*/
				        	 //p.sync();//同步
				         // p.close(); 
				        	 RedisUtil.close(jedis);
				        	 jedis=null;
						// p.close();	
				         
				        
		               } 
					
				     	catch (JedisConnectionException e) {
			             e.printStackTrace();
			           } 
				    	 catch (Exception e) {
				            e.printStackTrace();
				        }
    		break;
		case "2":
					/*String luaname =(String)taskdetial.get(0).get("luaname"); 
			    	logger.warn(luaname);
					try {
						 
						
							
						 jedis = RedisUtil.getJedis();
				        	Reader r = new InputStreamReader(QuartzJob.class.getResourceAsStream(luaname));
				            luaStr = CharStreams.toString(r);
				             jedis.eval(luaStr);
				            r.close();
				            r=null;
				            RedisUtil.close(jedis);
				            jedis=null;
					  }
				     	catch (JedisConnectionException e) {
			             e.printStackTrace();
			           } 
				    	 catch (Exception e) {
				            e.printStackTrace();
				        }*/
					logger.info("lua work ok");
			
			break;

		default:
			break;
		}
    	
    	//tmap.clear();
    	//tmap=null;

    }
    	
}
