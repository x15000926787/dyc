package com.dl.controller;

import com.alibaba.fastjson.JSON;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dl.impl.UserDAOImpl;
import com.dl.tool.Tool;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.security.GeneralSecurityException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jxl.write.WriteException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TfController
{
  @Autowired
  private UserDAOImpl user;

  @RequestMapping("test")
  public void test(String userId, HttpServletResponse response)
  {
	   Tool.request(user.test(),response);
  }
  
  @RequestMapping({"executeCmd"})
  public void executeCmd(String strcmd, HttpServletResponse response) throws Exception
  {
	   Tool.request(user.executeCmd(strcmd),response);
  }
  @RequestMapping({"rbt"})
  public void rbt(HttpServletResponse response) throws IOException
  {
	   Tool.request(user.rbt(),response);
  }
  @RequestMapping({"setRedisVal"})
  public void setRedisVal(Integer optype,String key, String val,String hlimit,HttpServletRequest request,HttpServletResponse response)
  {
	 
	  java.util.Map<String,Object> map1 = new HashMap<String,Object>();  
		 String jsonString="";
		 String sess=null;
		 sess =  String.valueOf(request.getSession().getAttribute("LOGIN_SUCCESS"));
	  if (!"null".equals(sess) )
	    Tool.request( user.setRedisVal(optype,key,val,hlimit,sess),response);
	  else {
		  map1.put("result",-2); 
		  jsonString = JSON.toJSONString(map1);
		  Tool.request( jsonString,response);
	}
  }
  @RequestMapping({"linkaction"})
  public void linkaction(String key, String val,HttpServletRequest request,HttpServletResponse response)
  {
	 
	  java.util.Map<String,Object> map1 = new HashMap<String,Object>();  
		 String jsonString="";
		 String sess=null;
		 sess =  String.valueOf(request.getSession().getAttribute("LOGIN_SUCCESS"));
	  if (!"null".equals(sess) )
	    Tool.request( user.linkaction(key,val,sess),response);
	  else {
		  map1.put("result",-2); 
		  jsonString = JSON.toJSONString(map1);
		  Tool.request( jsonString,response);
	}
  }
  @RequestMapping({"getRedisVal"})
  public void getRedisVal(String key,int type,HttpServletResponse response)
  {
	  
	    Tool.request( user.getRedisVal(key,type),response);
  }
 
  @RequestMapping({"login"})
  public void login(String uname, String pwd,HttpServletResponse response,HttpSession httpSession)
  {
	  
	    Tool.request( user.login(uname,pwd,httpSession),response);
  }
  @RequestMapping({"getMainRealGl"})
  public void getMainRealGl(String crew, int year,HttpServletResponse response)
  {

	    Tool.request( user.getMainRealGl(crew,year),response);
  }
  @RequestMapping({"sound"})
  public void sound(HttpServletResponse response) throws IOException
  {
	   Tool.request(user.sound(),response);
  }
  @RequestMapping({"getuser"})
  public void getuser(HttpServletResponse response) throws IOException
  {
	   Tool.request(user.getuser(),response);
  }
  @RequestMapping({"stopsound"})
  public void stopsound(HttpServletResponse response) throws IOException
  {
	   Tool.request(user.stopsound(),response);
  }
  @RequestMapping({"loadUser"})
  public void loadUser(HttpServletResponse response) throws IOException, ParseException
  {
	   Tool.request(user.loadUser(),response);
  }
  @RequestMapping({"logred"})
  public void logred(String uname,HttpServletResponse response) throws IOException, ParseException
  {
	   Tool.request(user.logred(uname),response);
  }
  @RequestMapping({"getTfList"})
  public void getTfList(HttpServletResponse response) throws ParseException
  {
	  Tool.request( user.getTfList(),response);
  }
  @RequestMapping({"getstatus"})
  public void getstatus(HttpServletResponse response) throws ParseException
  {
	  Tool.request( user.getstatus(),response);
  }
  @RequestMapping({"mysqltest"})
  public void mysqltest(String pno,HttpServletResponse response) throws ParseException
  {
	  Tool.request( user.mysqltest(pno),response);
  }
  @RequestMapping({"get_vals"})
  public void get_vals(String dt,String nm,int dno,String pno,HttpServletResponse response) throws ParseException, WriteException, IOException
  {
	  Tool.request( user.get_vals(dt,nm,dno,pno),response);
  }
  @RequestMapping({"savedsplan"})
  public void savedsplan(int all,String id,String oof,String op,String cl,HttpServletResponse response) throws ParseException, SQLException
  {
	  Tool.request( user.savedsplan(all,id,oof,op,cl),response);
  }
  @RequestMapping({"deldsplann"})
  public void deldsplann(String id,String op,String wk,HttpServletResponse response) throws ParseException, SQLException
  {
	  Tool.request( user.deldsplann(id,op,wk),response);
  }
  @RequestMapping({"savedsplann"})
  public void savedsplann(int all,String id,String oof,String op,String cl,String wk,HttpServletResponse response) throws ParseException, SQLException
  {
	  Tool.request( user.savedsplann(all,id,oof,op,cl,wk),response);
  }
  @RequestMapping({"deldsplann_temp"})
  public void deldsplann_temp(String id,String op,String st,String wk,HttpServletResponse response) throws ParseException, SQLException
  {
	  Tool.request( user.deldsplann_temp(id,op,st,wk),response);
  }
  @RequestMapping({"savedsplann_temp"})
  public void savedsplann_temp(int all,String id,String oof,String op,String cl,String wk,HttpServletResponse response) throws ParseException, SQLException
  {
	  Tool.request( user.savedsplann_temp(all,id,oof,op,cl,wk),response);
  }
  @RequestMapping({"loadconfig"})
  public void loadconfig(String dno,String nm,int lev,HttpServletResponse response) throws ParseException, IOException
  {
	  Tool.request( user.loadconfig(dno,nm,lev),response);
  }
  @RequestMapping({"loadrtuno"})
  public void loadrtuno(String pno,HttpServletResponse response) throws ParseException
  {
	  Tool.request( user.loadrtuno(pno),response);
  }
  @RequestMapping({"loaddsdevntemp"})
  public void loaddsdev_temp(HttpServletResponse response) throws ParseException
  {
	  Tool.request( user.loaddsdev_temp(),response);
  }
  @RequestMapping({"loaddsdev"})
  public void loaddsdev(HttpServletResponse response) throws ParseException
  {
	  Tool.request( user.loaddsdev(),response);
  }
  @RequestMapping({"loaddsdevn"})
  public void loaddsdevn(HttpServletResponse response) throws ParseException
  {
	  Tool.request( user.loaddsdevn(),response);
  }
  
  @RequestMapping({"loadconfig_xb"})
  public void loadconfig_xb(String dno,String nm,int lev,HttpServletResponse response) throws ParseException
  {
	  Tool.request( user.loadconfig_xb(dno,nm,lev),response);
  }
  @RequestMapping({"loaddsplan"})
  public void loaddsplan(int lev,HttpServletResponse response) throws ParseException
  {
	  Tool.request( user.loaddsplan(lev),response);
  }
  @RequestMapping({"getsession"})
  public void getsession(String snm,HttpServletResponse response,HttpSession httpSession) throws ParseException
  {
	  Tool.request( user.getsession(snm, httpSession),response);
  }
  @RequestMapping({"loadconfig_dl"})
  public void loadconfig_dl(String dno,String nm,int lev,HttpServletResponse response) throws ParseException
  {
	  Tool.request( user.loadconfig_dl(dno,nm,lev),response);
  }
  @RequestMapping({"loadconfig_dn"})
  public void loadconfig_dn(String dno,String nm,int lev,HttpServletResponse response) throws ParseException, IOException
  {
	  Tool.request( user.loadconfig_dn(dno,nm,lev),response);
  }
  @RequestMapping({"gettree"})
  public void gettree(String pno,HttpServletResponse response) throws ParseException
  {
	  Tool.request( user.gettree(pno),response);
  }
  @RequestMapping({"getyTfList"})
  public void getyTfList(HttpServletResponse response) throws ParseException
  {
	  Tool.request( user.getyTfList(),response);
  }
  @RequestMapping({"getTfPlanAll"})
  public void getTfPlanAll(String crew,String tab,int pId , HttpServletResponse response) throws ParseException
  {

	    Tool.request( user.getTfPlanAll(crew,tab,pId),response);
  }
  @RequestMapping({"getTfPlanAll_kb"})
  public void getTfPlanAll_kb(String crew,String tab,int pId , HttpServletResponse response) throws ParseException
  {

	    Tool.request( user.getTfPlanAll_kb(crew,tab,pId),response);
  }
  @RequestMapping({"getTfPlanAll_evt"})
  public void getTfPlanAll_evt(String crew,String tab,int pId,int ob ,String pno, HttpServletResponse response) throws ParseException
  {

	    Tool.request( user.getTfPlanAll_evt(crew,tab,pId,ob,pno),response);
  }
  @RequestMapping({"getTfPlanAll_xb"})
  public void getTfPlanAll_xb(String crew,String tab,String pId ,int nmd, HttpServletResponse response) throws ParseException
  {

	    Tool.request( user.getTfPlanAll_xb(crew,tab,pId,nmd),response);
  }
  @RequestMapping({"getTfPlanAll_dl"})
  public void getTfPlanAll_dl(String crew,String tab,String pId ,int nmd, HttpServletResponse response) throws ParseException
  {

	    Tool.request( user.getTfPlanAll_dl(crew,tab,pId,nmd),response);
  }
  @RequestMapping({"getyTfPlanAll"})
  public void getyTfPlanAll(int sn,String jz,int tab , HttpServletResponse response) throws ParseException
  {

	    Tool.request( user.getyTfPlanAll(sn,jz,tab),response);
  }
  @RequestMapping({"showgd"})
  public void showgd(int aid,int pid , HttpServletResponse response) throws ParseException
  {

	    Tool.request( user.showgd(aid,pid),response);
  }
  @RequestMapping({"getyTfPlanAll11"})
  public void getyTfPlanAll11(int sn,String jz,int tab , HttpServletResponse response) throws ParseException
  {

	    Tool.request( user.getyTfPlanAll11(sn,jz,tab),response);
  }
  @RequestMapping({"getplandl"})
  public void getplandl(int sn,String jz,int tab , HttpServletResponse response) throws ParseException
  {

	    Tool.request( user.getplandl(sn,jz,tab),response);
  }
  @RequestMapping({"getyPlanAll"})
  public void getyPlanAll(int sn,String jz,int tab , HttpServletResponse response) throws ParseException
  {

	    Tool.request( user.getyPlanAll(sn,jz,tab),response);
  }
  @RequestMapping({"getTfPlanAllByTime"})
  public void getTfPlanAllByTime(String planTime,String jz,int tab , HttpServletResponse response) throws ParseException
  {

	    Tool.request( user.getTfPlanAllByTime(planTime,jz,tab),response);
  }
  
  @RequestMapping({"newTfPlan"})
  public void newTfPlan(int year, String pName,HttpServletResponse response) throws ParseException, SQLException
  {

	    Tool.request( user.newTfPlan(year, pName),response);
  }
  @RequestMapping({"updateTfPlan"})
  public void updateTfPlan(int dsn, String p_exp,HttpServletResponse response) throws ParseException, SQLException
  {

	    Tool.request( user.updateTfPlan(dsn, p_exp),response);
  }
  @RequestMapping({"getdlData"})
  public void getdlData(String crew,String crewLong, int pId,HttpServletResponse response) throws ParseException
  {
	    Tool.request( user.getdlData(crew, crewLong,pId),response);
  }
  @RequestMapping({"getTfData"})
  public void getTfData(String crew,String crewLong, int pId,HttpServletResponse response) throws ParseException
  {
	    Tool.request( user.getTfData(crew, crewLong,pId),response);
  }
  @RequestMapping({"getTfData_gzr"})
  public void getTfData_gzr(String crew,String crewLong, int pId,HttpServletResponse response) throws ParseException
  {
	    Tool.request( user.getTfData_gzr(crew, crewLong,pId),response);
  }
  @RequestMapping({"getTfData_xb"})
  public void getTfData_xb(String crew,String crewLong, String pId,HttpServletResponse response) throws ParseException
  {
	    Tool.request( user.getTfData_xb(crew, crewLong,pId),response);
  }
  @RequestMapping({"getTfData_dl"})
  public void getTfData_dl(String crew,String crewLong, String pId,HttpServletResponse response) throws ParseException
  {
	    Tool.request( user.getTfData_dl(crew, crewLong,pId),response);
  }
  @RequestMapping({"chgPwd"})
  public void chgPwd(String uname,String opwd,String npwd,HttpServletResponse response) throws ParseException
  {
	    Tool.request( user.chgPwd(uname,opwd, npwd),response);
  }
  @RequestMapping({"getyTfData"})
  public void getyTfData(String crew,String crewLong, int pId,HttpServletResponse response) throws ParseException
  {
	    Tool.request( user.getyTfData(crew, crewLong,pId),response);
  }
  @RequestMapping({"saveTfEdit"})
  public void saveTfEdit(String jsonStr,int sn , HttpServletResponse response) throws ParseException
  {
	   try
		{
		   Tool.request( user.saveTfEdit(jsonStr,sn),response);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
  }
  @RequestMapping({"saveUser"})
  public void saveUser(String jsonStr,int sn , HttpServletResponse response) throws ParseException
  {
	   try
		{
		   Tool.request( user.saveUser(jsonStr,sn),response);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
  }
  @RequestMapping({"getUserAuthor"})
  public void getUserAuthor(int uId, HttpServletResponse response) throws ParseException 
  { 
	  Tool.request(this.user.getUserAuthor(uId), response); 
	  }
  @RequestMapping({"getauthor"})
  public void getauthor(HttpServletResponse response) throws ParseException { Tool.request(this.user.getauthor(), response); }
  @RequestMapping({"set_author"})
  public void set_author(String devs, int uid, HttpServletResponse response) { Tool.request(this.user.set_author(devs, uid), response); }
  @RequestMapping({"loadconfig_updown"})
  public void loadconfig_updown(String dno, String nm, int lev, HttpServletResponse response) throws ParseException { Tool.request(this.user.loadconfig_updown(dno, nm, lev), response); }
  @RequestMapping({"testHelper"})
  public void testHelper(int pId, HttpServletResponse response) throws ParseException { Tool.request(this.user.testHelper(pId), response); }
  @RequestMapping({"loadconfig_updown_cn"})
  public void loadconfig_updown_cn(String dno, String nm, int lev, HttpServletResponse response) throws ParseException { Tool.request(this.user.loadconfig_updown_cn(dno, nm, lev), response); }

  
  @RequestMapping({"saveupdown"})
  public void saveupdown(String jsonStr, int sn, HttpServletResponse response) throws ParseException {
    try {
      Tool.request(this.user.saveupdown(jsonStr, Integer.valueOf(sn)), response);
    }
    catch (SQLException e) {
      
      e.printStackTrace();
    } 
  }

  
  @RequestMapping({"syncupdown"})
  public void syncupdown(HttpServletResponse response) throws ParseException, SQLException { Tool.request(this.user.syncupdown(), response); }

  
  @RequestMapping({"saveyTfEdit"})
  public void saveyTfEdit(String jsonStr,int sn , HttpServletResponse response) throws ParseException
  {
	   try
		{
		   Tool.request( user.saveyTfEdit(jsonStr,sn),response);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
  }
  @RequestMapping({"savegdEdit"})
  public void savegdEdit(String jsonStr,int mark ,int evt, HttpServletResponse response) throws ParseException
  {
	   try
		{
		   
		   Tool.request( user.savegdEdit(jsonStr,mark,evt),response);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
  }
  @RequestMapping({"tfExport"})
  public void tfExport(int sn,int tab,int mode,String key, HttpServletResponse response)
  {
	  String from="";
	  String to="";
	  if(mode==2)
	  {
		  String[] keyArr=key.split("\\|");
		  from=keyArr[0];
		  to=keyArr[1];
	  }
	  Tool.request( user.tfExport(sn,tab,mode,from,to),response);
  }

  @RequestMapping({"doinfo"})
  public void doinfo(String key, int mode, String crew , String crewLong , HttpServletResponse response) throws ParseException 
  {
	  
	  if(mode==1)
	  { 
		  Tool.request(   user.doinfo(key,mode),response);
	  }
	  else if (mode==2)
	  {
		  Tool.request(   user.doinfo(key,mode),response);
	  }
	  else
	  {
		  String[] keyArr=key.split("\\|");
		  String from=keyArr[0];
		  String to=keyArr[1];
		  Tool.request(   user.doTfTimeSearch(from,to,crew,crewLong),response);
	  }
	  
  }
  @RequestMapping({"delgd"})
  //aid: aids, pid: pids, crew: nowJz, crewLong: nowJzLong 
  public void delgd(int aid, int pid, int crew , String crewLong , HttpServletResponse response) throws ParseException 
  {
	  
	  user.log("delete:"+aid);
		  Tool.request(   user.delgd(aid,pid),response);
	 
	  
  }
  @RequestMapping({"doTfSearch"})
  public void doTfSearch(String key, int mode, String crew , String crewLong , HttpServletResponse response) throws ParseException 
  {
	  if(mode==1)
	  { 
		  Tool.request(   user.doTfSearch(key),response);
	  }
	  else
	  {
		  String[] keyArr=key.split("\\|");
		  String from=keyArr[0];
		  String to=keyArr[1];
		  Tool.request(   user.doTfTimeSearch(from,to,crew,crewLong),response);
	  }
  }

  @RequestMapping({"tfdcs"})
  public void tfdcs(String crew, String crewLong , int pId, int tab,int mode,String key,HttpServletResponse response) throws ParseException
  {

	  int num=1;
	  ArrayList jzArr=new ArrayList();  
	  ArrayList jzLongArr=new ArrayList();  
	  ArrayList dataArr=new ArrayList();  
	  

	  if(crew.endsWith("all"))
	  {
		  num=10;
		  jzArr.add("all");
		  jzArr.add("Q1-1");
		  jzArr.add("Q2-1");
		  jzArr.add("Q2-2"); 
		  jzArr.add("Q2-3"); 
		  jzArr.add("Q2-4"); 
		  jzArr.add("Q3-1");
		  jzArr.add("Q3-2");
		  jzArr.add("F1-1");
		  jzArr.add("F1-2"); 

		  jzLongArr.add("all");
		  jzLongArr.add("QM_GYD010WZ");
		  jzLongArr.add("1RCP009VE");
		  jzLongArr.add("2RCP009VE"); 
		  jzLongArr.add("3RCP010VE"); 
		  jzLongArr.add("4RCP010VE");
		  jzLongArr.add("U1_AI2565");
		  jzLongArr.add("U2_AI2565");
		  jzLongArr.add("1GRE012MY_AVALUE_RT");
		  jzLongArr.add("2GRE012MY_AVALUE_RT"); 
	  }
	  else if(crew.endsWith("p_1"))
	  {
		  num=2;
		  jzArr.add("p_1");
		  jzArr.add("Q1-1");
		  jzLongArr.add("p_1");
		  jzLongArr.add("QM_GYD010WZ");
	  }
	  else if(crew.endsWith("p_2"))
	  {
		  num=5;
		  jzArr.add("p_2");
		  jzArr.add("Q2-1");
		  jzArr.add("Q2-2"); 
		  jzArr.add("Q2-3"); 
		  jzArr.add("Q2-4"); 
		  jzLongArr.add("p_2");
		  jzLongArr.add("1RCP009VE");
		  jzLongArr.add("2RCP009VE"); 
		  jzLongArr.add("3RCP010VE"); 
		  jzLongArr.add("4RCP010VE");
	  }
	  else if(crew.endsWith("p_3"))
	  {
		  num=3;
		  jzArr.add("p_3");
		  jzArr.add("Q3-1");
		  jzArr.add("Q3-2");
		  jzLongArr.add("p_3");
		  jzLongArr.add("U1_AI2565");
		  jzLongArr.add("U2_AI2565");
	  }
	  else if(crew.endsWith("p_4"))
	  {
		  num=3;
		  jzArr.add("p_4");
		  jzArr.add("F1-1");
		  jzArr.add("F1-2"); 
		  jzLongArr.add("p_4");
		  jzLongArr.add("1GRE012MY_AVALUE_RT");
		  jzLongArr.add("2GRE012MY_AVALUE_RT"); 
	  }
	  else
	  {
		  jzArr.add(crew); 
		  jzLongArr.add(crewLong);
	  }
	  java.util.Map<String,Object> map = new HashMap<String,Object>();  
	  
	  if(mode==1)
	  {
			for (int i= 0; i<num; i++)
			{
				dataArr.add((Map<String,String>)JSON.parse(user.getTfData(jzArr.get(i).toString(), jzLongArr.get(i).toString(),pId)));
			}
			if(num==1)
			{
				dataArr.add(null);
			}
			map.put("data",dataArr);  
	  }
	  else
	  {
		  String[] keyArr=key.split("\\|");
		  String from=keyArr[0];
		  String to=keyArr[1];
			for (int i= 0; i<num; i++)
			{
				dataArr.add((Map<String,String>)JSON.parse(user.doTfTimeSearch(from,to,jzArr.get(i).toString(), jzLongArr.get(i).toString())));
			}
			if(num==1)
			{
				dataArr.add(null);
			}
			map.put("data",dataArr);  
	  }
		map.put("result",1);  
	 String jsonString = JSON.toJSONString(map);
	  Tool.request( jsonString,response);
  }
  @RequestMapping({"fdjhdcs"})
  public void fdjhdcs(String crew, String crewLong , int pId, int tab,int mode,String key,HttpServletResponse response) throws ParseException
  {

	  int num=1;
	  ArrayList jzArr=new ArrayList();  
	  ArrayList jzLongArr=new ArrayList();  
	  ArrayList dataArr=new ArrayList();  
	  

	  if(crew.endsWith("all"))
	  {
		  num=10;
		  jzArr.add("all");
		  jzArr.add("Q1-1");
		  jzArr.add("Q2-1");
		  jzArr.add("Q2-2"); 
		  jzArr.add("Q2-3"); 
		  jzArr.add("Q2-4"); 
		  jzArr.add("Q3-1");
		  jzArr.add("Q3-2");
		  jzArr.add("F1-1");
		  jzArr.add("F1-2"); 

		  jzLongArr.add("all");
		  jzLongArr.add("QM_GYD010WZ");
		  jzLongArr.add("1RCP009VE");
		  jzLongArr.add("2RCP009VE"); 
		  jzLongArr.add("3RCP010VE"); 
		  jzLongArr.add("4RCP010VE");
		  jzLongArr.add("U1_AI2565");
		  jzLongArr.add("U2_AI2565");
		  jzLongArr.add("1GRE012MY_AVALUE_RT");
		  jzLongArr.add("2GRE012MY_AVALUE_RT"); 
	  }
	  else if(crew.endsWith("p_1"))
	  {
		  num=2;
		  jzArr.add("p_1");
		  jzArr.add("Q1-1");
		  jzLongArr.add("p_1");
		  jzLongArr.add("QM_GYD010WZ");
	  }
	  else if(crew.endsWith("p_2"))
	  {
		  num=5;
		  jzArr.add("p_2");
		  jzArr.add("Q2-1");
		  jzArr.add("Q2-2"); 
		  jzArr.add("Q2-3"); 
		  jzArr.add("Q2-4"); 
		  jzLongArr.add("p_2");
		  jzLongArr.add("1RCP009VE");
		  jzLongArr.add("2RCP009VE"); 
		  jzLongArr.add("3RCP010VE"); 
		  jzLongArr.add("4RCP010VE");
	  }
	  else if(crew.endsWith("p_3"))
	  {
		  num=3;
		  jzArr.add("p_3");
		  jzArr.add("Q3-1");
		  jzArr.add("Q3-2");
		  jzLongArr.add("p_3");
		  jzLongArr.add("U1_AI2565");
		  jzLongArr.add("U2_AI2565");
	  }
	  else if(crew.endsWith("p_4"))
	  {
		  num=3;
		  jzArr.add("p_4");
		  jzArr.add("F1-1");
		  jzArr.add("F1-2"); 
		  jzLongArr.add("p_4");
		  jzLongArr.add("1GRE012MY_AVALUE_RT");
		  jzLongArr.add("2GRE012MY_AVALUE_RT"); 
	  }
	  else
	  {
		  jzArr.add(crew); 
		  jzLongArr.add(crewLong);
	  }
	  java.util.Map<String,Object> map = new HashMap<String,Object>();  
	  
	  if(mode==1)
	  {
			for (int i= 0; i<num; i++)
			{
				dataArr.add((Map<String,String>)JSON.parse(user.getyTfData(jzArr.get(i).toString(), jzLongArr.get(i).toString(),pId)));
			}
			if(num==1)
			{
				dataArr.add(null);
			}
			map.put("data",dataArr);  
	  }
	  else
	  {
		  String[] keyArr=key.split("\\|");
		  String from=keyArr[0];
		  String to=keyArr[1];
			for (int i= 0; i<num; i++)
			{
				dataArr.add((Map<String,String>)JSON.parse(user.doTfTimeSearch(from,to,jzArr.get(i).toString(), jzLongArr.get(i).toString())));
			}
			if(num==1)
			{
				dataArr.add(null);
			}
			map.put("data",dataArr);  
	  }
		map.put("result",1);  
	 String jsonString = JSON.toJSONString(map);
	  Tool.request( jsonString,response);
  }
  public UserDAOImpl getUserDao()
  {
    return this.user;
  }
  
  public void setUserDao(UserDAOImpl userDao)
  {
    this.user = userDao;
  }
}
