package com.bjsxt.server;

import java.io.IOException;
import com.bjsxt.thread.ThreadDemo;
import com.bjsxt.thread.ThreadSubscriber;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.Gson;


@ServerEndpoint("/chatSocket")
public class ChatSocket {

	
	/**
	 * @return the sockets
	 */
	public static Set<ChatSocket> getSockets() {
		return sockets;
	}




	/**
	 * @param sockets the sockets to set
	 */
	public static void setSockets(Set<ChatSocket> sockets) {
		ChatSocket.sockets = sockets;
	}

	private  static  Set<ChatSocket>  sockets=new HashSet<ChatSocket>();
//	private  static  Map<String, ChatSocket>  sMap=new HashMap<String, ChatSocket>();
	private static final Logger logger = LogManager.getLogger(ThreadSubscriber.class);
	private  static  List<String>   names=new ArrayList<String>();
	private  Session  session;
	private String username;
	//private ThreadDemo T1 = null;
	//private ThreadSubscriber T2 = null;
	private Gson  gson=new Gson();
	
	@OnOpen
	public  void open(Session  session){
		    
			this.session=session;
			sockets.add(this);
			
			String  queryString = session.getQueryString();
			logger.warn(queryString+"---"+this.session.getId());
			this.username = queryString.substring(queryString.indexOf("=")+1);
			names.add(this.username);
			
			
			//当websocket客户端连接成功，建立ThreadDemo线程，从实时库取数据
			/**/
	    /*    T2 = new ThreadSubscriber("thread_subscriber"+this.session.getId(),this.session);
		    try {
		    	 T2.start();
			} catch (Exception e) {
				logger.error(e.toString());
			}
		    T1 = new ThreadDemo(this.session.getId(),this.session);
		    T1.start();*/
//			
			
	}
	
	
	
	
	@OnError
	public void onError(Session session, Throwable error) {  
        logger.warn("发生错误");  
        error.printStackTrace();  
    }  
	@OnMessage
	public  void receive(Session  session,String msg ){
		
		/*Message  message=new Message();
		message.setSendMsg(msg);
		message.setFrom(this.username);
		message.setDate(new Date().toLocaleString());*/
		
		broadcast(sockets, gson.toJson(msg));
	}
	
	@OnClose
	public  void close(Session session){
		names.remove(this.username);
		/*T1.killThreadByName(this.session.getId());
		
		if (T2.killThreadByName("thread_subscriber"+this.session.getId())) 
			logger.warn("thread_subscriber"+this.session.getId()+":  have been closed");*/
		sockets.remove(this);
		logger.warn(this.username+"再见");
		//broadcast(sockets, gson.toJson(message));
	}
	
	public void broadcast(Set<ChatSocket>  ss ,String msg ){
		
		for (Iterator iterator = ss.iterator(); iterator.hasNext();) {
			ChatSocket chatSocket = (ChatSocket) iterator.next();
			try {
				synchronized(chatSocket.session){
					 
					chatSocket.session.getBasicRemote().sendText(msg);
				 
				}
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
   
	
}
