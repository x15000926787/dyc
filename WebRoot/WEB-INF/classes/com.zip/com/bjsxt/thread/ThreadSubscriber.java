/**  
* Title: ThreadSubscriber.java  
* Description: 
* @author：xx 
* @date 2019-6-18
* @version 1.0
* Company: www.zoutao.info
*/ 
package com.bjsxt.thread;

/**
 *@class_name：ThreadSubscriber
 *@comments:
 *@param:
 *@return: 
 *@author:xx
 *@createtime:2019-6-18
 */

import com.alibaba.fastjson.JSONObject;
import com.bjsxt.server.ChatSocket;
import com.dl.quartz.LuaJob;
import com.dl.tool.*;
import com.google.common.io.CharStreams;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPubSub;
import redis.clients.jedis.exceptions.JedisConnectionException;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

public class ThreadSubscriber  extends Thread {
	 private Thread t;
	 private boolean reconn=true;
	/* private boolean subbreak=true;*/
	 //RedisUtil jpool = new RedisUtil();
	  Jedis jedis = null;
	 //public Jedis jedis2 = null;
	// private Session thesesion;
	 private String threadName;
	 public ChatSocket ckt = new ChatSocket();
	 KeyExpiredListener myListener =null;  
	 //JedisPool pool = new JedisPool(new JedisPoolConfig(), "218.78.29.130", 6389, 10000,"Shcs123");
	 SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
	 private static final Logger logger = LogManager.getLogger(ThreadSubscriber.class);
	 String pId = FirstClass.projectId;
	
	 public ThreadSubscriber(String name){
		// thesesion = sess;
		 threadName = name;
		 logger.warn(threadName+":   start the subscriber thread");
		 Thread.currentThread().setName(threadName);
		 
		 //logger.warn("ThreadSubscriber.jpool:"+jpool.toString());
		// timer = new Timer();
		
	 }
	 private static void config(Jedis jediss){
	        String parameter = "notify-keyspace-events";
	        List<String> notify = jediss.configGet(parameter);
	        logger.warn(notify.toString());
	        if(notify.get(1).indexOf("AKE")<0){
	        	 logger.warn(notify.toString());
	        jediss.configSet(parameter, "AKE");
	        logger.warn(notify.toString());
	        }
	    }

	  public void run() {
		  logger.warn("Running thread_subscriber"  );
	     // Thread.currentThread().setName("thread_subscriber"+thesesion);

	       
	     
	    	 
	    	//jedis2 = jpool.getJedis();
	        while(reconn){
	        	
	        	 try {
	        	 jedis = RedisUtil.getJedis();
	        	
	   	        config(jedis);  
	   	    
	   	        myListener= new KeyExpiredListener(ckt); 
	   	    
	   	      
	 	    /* timer.schedule(new TimerTask() 
	 	       {
	             public void run() {
	            	// if (subbreak)  myListener.punsubscribe("__key*__:*"); 
	             }
	            }, 60000, 60000);//  
*/
	   	     //jedis.set("subscriber.stat",df.format(new Date()));
	        	 try {
	             	jedis.psubscribe(myListener, "__keyevent@"+pId+"__:*");
	 			} 
	        	 catch (JedisConnectionException e){
	        		 e.printStackTrace();
	                logger.warn("Exception :", e.toString());

	                RedisUtil.close(jedis); 
	               jedis=null;

	            }
	        	 catch (ClassCastException e) {
	            	 logger.warn("Exception :", e.toString());
		            e.printStackTrace();
		        } 
	        	 catch(Exception e){
	        		 logger.error("Exception:", e.toString());
	            	e.printStackTrace();
	                

	            }
	        	
	        	 
	          /*  try{
	            	 logger.warn("waiting for 2s");
	                Thread.sleep(2000);

	            }catch(Exception unused){

	            }*/
	        	  }catch (Exception e) {
	    	    	  logger.warn("Thread " +  Thread.currentThread().getName() + " interrupted."+e.toString());
	    		  }
	        }
	    
		  
	      logger.warn("Thread " +  threadName + " exiting.");
	        
	  }
	   
	   public void start () {
		   logger.warn("Starting " +  threadName );
	      if (t == null) {
	         t = new Thread (this, threadName);
	         t.start ();
	      }
	   }
	   public void stoplisten () {
		   logger.warn("Stop " +  "thread_subscriber" );
		      reconn= false;
		      myListener.punsubscribe("__keyevent@"+pId+"__:*");
		     /* try {
				  if (jedis != null) {

		              jedis.close();

			          }
				  } catch (JedisException e) {
						e.printStackTrace();
					}catch (Exception e) {
						e.printStackTrace();
					}*/
		   }
	   public  boolean killThreadByName(String name ) {
		    stoplisten ();
			ThreadGroup currentGroup = Thread.currentThread().getThreadGroup();
	 
			int noThreads = currentGroup.activeCount();
	 
			Thread[] lstThreads = new Thread[noThreads];
	 
			currentGroup.enumerate(lstThreads);
	 
			//System.out.println("现有线程数" + noThreads);
	 
			for (int i = 0; i < noThreads; i++) {
	 
				String nm = lstThreads[i].getName();
	 
				//System.out.println("线程号：" + i + " = " + nm);
	 
				if (nm.equals(name)) {
					logger.warn("关闭线程："  +  nm);
					lstThreads[i].interrupt();
	 
					return true;
	 
				}
	 
			}
	 
			return false;
	 
		}
	   /*
	   static class MyTask() extends TimerTask { 
		   @Override
		   public void run() {
			  // jedis.set("subscriber.stat",df.format(new Date()));
		   }
		   }*/
}


class KeyExpiredListener extends JedisPubSub {
	public ChatSocket skt;
	
	
	 public JSONObject objana = new JSONObject();
	 public JSONObject msg_user = new JSONObject();
	 public JSONObject msg_author = new JSONObject();
	 public JSONObject objcondition = new JSONObject();
	 
	 public Jedis tjedis = null;
	 public static JdbcTemplate jdbcTemplate;
		
	 SendViaWs sendmsg = new SendViaWs();
		  
	private static final Logger logger = LogManager.getLogger(KeyExpiredListener.class);
	 public KeyExpiredListener(ChatSocket sskt) throws SQLException{
		 skt = sskt;  
		 objana = loadPrtu();
		 msg_user = loaduser();
		 msg_author = loadauthor();
		 objcondition = loadCondition();
		// logger.warn(msg_user);
		// logger.warn(msg_author);
	 }
	 
    @Override
    public void onPSubscribe(String pattern, int subscribedChannels) {
    	logger.warn("onPSubscribe " + pattern + " " + subscribedChannels);
    	tjedis = RedisUtil.getJedis();
    }
    @Override
    public void onPUnsubscribe(String pattern, int subscribedChannels) {
    	  RedisUtil.close(tjedis);
    	  tjedis=null;
    	/*try {
    		if (tjedis != null) {

                tjedis.close();

            }
		} catch (Exception e) {
			// TODO: handle exception
		}*/
    	 
    	//logger.warn("onPUnsubscribe close " + pattern + " " + subscribedChannels);
    }
   
	 /**
	     * 读取信息表
	     * @param 
	 * @throws SQLException 
	    
	     */  
	   
	   public JSONObject loadPrtu() throws SQLException {
		   JSONObject tobj =new JSONObject();
		   DBConnection dbcon=new DBConnection();
		   PreparedStatement pstmt=null;
		   ResultSet rs=null;
		   int i=0,maxsav=0,maxdnsav=0;
		   String key="",value="";
		   String sql="select rtuno,sn,kkey,saveno,upperlimit,lowerlimit,pulsaveno,chgtime,deviceno  from prtuana_v";
			//if(rand.equalsIgnoreCase(imagerand)){
	    		try{
					pstmt=dbcon.setPreparedStatement(sql);
					
					rs=dbcon.getPrepatedResultSet();
              
					 ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData(); 
					 int colCount=rsmd.getColumnCount();
					 List<String> colNameList=new ArrayList<String>();
					 for( i=0;i<colCount;i++){
						 colNameList.add(rsmd.getColumnName(i+1));
					 } 
					 while(rs.next()){ 
						 Map map=new HashMap<String, Object>();
						 for( i=0;i<colCount;i++){
							 key=colNameList.get(i);
							 value=rs.getString(colNameList.get(i));
							 map.put(key, value);  
						 }
						 //results.add(map);
						 maxsav=(rs.getInt("saveno")>maxsav?rs.getInt("saveno"):maxsav);
						 try
						 {
							 maxdnsav=(rs.getInt("pulsaveno")>maxdnsav?rs.getInt("pulsaveno"):maxdnsav); 
						 }
						 catch(Exception e)
						 {}
						 tobj.put(map.get("kkey").toString(),map);
						
					 }
					 tobj.put("maxsav",maxsav);
					 tobj.put("maxdnsav",maxdnsav);
		        // pstmt.close();
		        // dbcon.getClose();
				}catch(SQLException e){
					logger.error("ana出错了"+e.toString());
				}
	    		//logger.warn(objana);
				sql="select rtuno,sn,type ,kkey,chgtime,deviceno  from prtudig";
			//if(rand.equalsIgnoreCase(imagerand)){
				try{
					pstmt=dbcon.setPreparedStatement(sql);
					
					rs=dbcon.getPrepatedResultSet();
					
					 ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData(); 
						 int colCount=rsmd.getColumnCount();
						 List<String> colNameList=new ArrayList<String>();
						 for( i=0;i<colCount;i++){
							 colNameList.add(rsmd.getColumnName(i+1));
						 } 
						 while(rs.next()){ 
							 Map map=new HashMap<String, Object>();
							 for( i=0;i<colCount;i++){
								 key=colNameList.get(i);
								 value=rs.getString(colNameList.get(i));
								 map.put(key, value);  
							 }
							 //results.add(map);
							 tobj.put(map.get("kkey").toString(),map);
							 
						
						 }
		        // pstmt.close();
		         //dbcon.getClose();
				}catch(SQLException e){
					logger.error("出错了"+e.toString());
				}
				try
				{
					if (pstmt!=null) pstmt.close();
					pstmt = null;
					if (dbcon!=null) dbcon.getClose();
					dbcon = null;
				}catch(SQLException e){
					logger.error("出错了"+e.toString());
				}
				//logger.warn(tobj);
		return tobj;
		
	} 
	   /**
	     * 读取yonghubiao
	     * @param 
	 * @throws SQLException 
	    
	     */  
	   
	   public JSONObject loaduser() throws SQLException {
		   JSONObject tobj = new JSONObject();
		   DBConnection dbcon=new DBConnection();
		   int i=0,maxsav=0,maxdnsav=0;
		   String key="",value="";
		   String sql="select *  from msg_user";
		   List<Map<String, Object>> lmsg_user = new ArrayList<Map<String, Object>>();
		   
		   try{
				//pstmt=dbcon.setPreparedStatement(sql);
				
			   lmsg_user=  dbcon.queryforList(sql);
			   //logger.warn(lmsg_user);
				for (Map<String, Object> tmap:lmsg_user){					
						
						tobj.put(tmap.get("id").toString(), tmap);
					
	    		}
	    
          // pstmt.close();
          // dbcon.getClose();
			}catch(Exception e){
				logger.warn("loaduser出错了"+e.toString());
			}
		   try
			{
				
				if (dbcon!=null) dbcon.getClose();
				dbcon = null;
			}catch(Exception e){
				System.out.println("出错了"+e.toString());
			}
	    		//logger.warn(objana);
				
				//logger.warn(tobj);
		return tobj;
		
	} 
	   /**
	     * 读取权限表
	     * @param 
	 * @throws SQLException 
	    
	     */  
	   
	   public JSONObject loadauthor() throws SQLException {
		   JSONObject tobj = new JSONObject();
		   DBConnection dbcon=new DBConnection();
		   int i=0,maxsav=0,maxdnsav=0;
		   String key="",value="";
		   String sql="select *  from dev_author";
		   List<Map<String, Object>> lmsg_user = new ArrayList<Map<String, Object>>();
		   try{
				//pstmt=dbcon.setPreparedStatement(sql);
				
			   lmsg_user= dbcon.queryforList(sql);
				for (Map<String, Object> tmap:lmsg_user){					
						
						tobj.put(tmap.get("deviceno").toString(), tmap);
					
	    		}
	    
         // pstmt.close();
         // dbcon.getClose();
			}catch(Exception e){
				logger.warn("loadauthor出错了"+e.toString());
			}
		   try
			{
				
				if (dbcon!=null) dbcon.getClose();
				dbcon = null;
			}catch(Exception e){
				System.out.println("出错了"+e.toString());
			}	//logger.warn(objana);
				
				//logger.warn(tobj);
		return tobj;
		
	} 
	   /**
	     * 读取信息表conditionslua
	     * @param 
	 * @throws SQLException 
	    
	     */  
	   
	   public JSONObject loadCondition() throws SQLException {
		   JSONObject tobj =new JSONObject();
		   
		   DBConnection dbcon=new DBConnection();
		   
		   
		   String key="",value="",key2=" ";
		   String sql="select *  from conditionlua";
			//if(rand.equalsIgnoreCase(imagerand)){
	    		try{
					
					List<Map<String, Object>> userData = dbcon.queryforList(sql);
					List<Map<String, Object>> nobj =  new ArrayList<Map<String, Object>>();
					int size=userData.size() ;
    			    if (size> 0)
    			    {
    			    	for (int i = 0; i<size; i++)
    			    	{	
    			    		Map map = (HashMap) userData.get(i);
    			    		key = map.get("kkey").toString();
    			    	
    			    	    if (!key.matches(key2) ){
    			    	    	
    			    	    	if (i!=0){
    			    	    		tobj.put(key, nobj);
    			    	    		nobj.clear();
    			    	    	}
    			    	    	
    			    	    	nobj.add(map);
    			    	    	key2 = key;
    			    	    	
    			    	    }else
    			    	    {
    			    	    	
    			    	    	nobj.add(map);
    			    	    }
    			    	    tobj.put(key, nobj);
    			    	    //tobj.put(map.get("kkey").toString(),map);
    			    	}
    			    	
    			    }
				}catch(Exception e){
					logger.error("condition出错了"+e.toString());
				}
	    		
				try
				{
					
					if (dbcon!=null) dbcon.getClose();
					dbcon = null;
				}catch(Exception e){
					System.out.println("出错了"+e.toString());
				}
				//logger.warn(tobj);
		return tobj;
		
	} 
	 /**
	     * 检查遥测越限
	     * @param 
	     * @throws ScriptException 
	     */  
	   
	   public int checkupdown(String val,String down,String up,int stat) {
		   int st=-2;
		   //logger.warn("check updown : " +  val+":"+  up+":"+  down+":"+  stat );
		  
		   ScriptEngineManager scriptEngineManager = new ScriptEngineManager();
	       ScriptEngine scriptEngine = scriptEngineManager.getEngineByName("nashorn");
	       try
	       {
	    	   if ((boolean) scriptEngine.eval(val+"<"+down) && stat>-1)
		    	   st = -1;
		       if ((boolean) scriptEngine.eval(val+">"+up) && stat<1)
		    	   st = 1; 
		       if ((boolean) scriptEngine.eval(val+">="+down)&&(boolean) scriptEngine.eval(val+"<="+up) && stat!=0)
		    	   st = 0; 

	       }catch (ScriptException e) {
	        	logger.error("check updown err: " +  e.toString() );
	            e.printStackTrace();
	        }
	       //logger.warn("st : " +  st );
		return st;
		
	} 
	   /**
	     * 检查condition
	     * @param 
	     * @throws ScriptException 
	     */  
	   
	   public boolean checkcondition(String val,String condition) {
		   boolean st=false;
		  
		   ScriptEngineManager scriptEngineManager = new ScriptEngineManager();
	       ScriptEngine scriptEngine = scriptEngineManager.getEngineByName("nashorn");
	       try
	       {
	    	   if ((boolean) scriptEngine.eval(val+condition) )
		    	   st = true;
		      

	       }catch (ScriptException e) {
	        	logger.error("check updown err: " +  e.toString() );
	            e.printStackTrace();
	        }

		return st;
		
	} 
	   /**
	     * 检查遥信变位
	     * @param 
	     * @throws ScriptException 
	     */  
	   
	   public int checkevt(String val,int stat) {
		   int st = 0;
		   if (stat!=-1)
		   {
		   ScriptEngineManager scriptEngineManager = new ScriptEngineManager();
	        ScriptEngine scriptEngine = scriptEngineManager.getEngineByName("nashorn");
	       try
	       {
	    	  
		       if ((boolean) scriptEngine.eval(val+"!="+stat) )
		       {
		    	   st = 1; 
		    	   //logger.info("checkevt: " +  val+"!="+stat );
		       }
		      

	       }catch (ScriptException e) {
	        	logger.error("check updown err: " +  e.toString() );
	            e.printStackTrace();
	        }
		   }
		return st;
		
	} 
	    /*
	     * 插入记录
	     * getPrepatedResultSet
	     */
	  public void add_red(String sql)
	  {
		  DBConnection dbcon=new DBConnection();
		  
		  //logger.warn(sql);
		  try{
			  dbcon.setPreparedStatement(sql);
			  int t=dbcon.getexecuteUpdate();
	          //dbcon.getClose();
			}catch(Exception e){
				logger.error("出错了"+e.toString());
			}
		  dbcon.getClose();
		  dbcon=null;
	  }
	  /*
	     * 查询信息
	     * getPrepatedResultSet
	     */
	  public String query_red(String sql)
	  {
		  String msg=null;
		  DBConnection dbcon=new DBConnection();
		  
		  //logger.warn(sql);
		  try{
			  dbcon.setPreparedStatement(sql);
			  ResultSet t=dbcon.getPrepatedResultSet();
			  t.next();
	          msg= t.getString("msg");
			}catch(Exception e){
				logger.error("出错了"+e.toString());
			}
		  dbcon.getClose();
		  dbcon=null;
		return msg;
	  }
    public void handleEvt(String key,String vals) {
    	String down,up,rtuno,sn,dbname,dbname2,msgah,mailah,mobs = "";
    	Calendar c;
    	SimpleDateFormat df,df2,df3;
  	 	HashMap<String,String>  map = new HashMap<String,String>();
  	 	HashMap<String,Object>  authormap = new HashMap<String,Object>();
  	 	HashMap<String,String>  usermap = new HashMap<String,String>();
  	 	
  	 	//logger.error(key);
	  	map = (HashMap<String,String>)objana.get(key);
	

		  df = new SimpleDateFormat("YYMMdd");//设置日期格式
		  df2 = new SimpleDateFormat("HHmmss");//设置日期格式
		  df3 = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");//设置日期格式
		// savet = (df.format(new Date()));// new Date()为获取当前系统时间
		  c = Calendar.getInstance();//可以对每个时间域单独修改
		 dbname = "hevtyc"+(c.get(Calendar.YEAR)%10); 
		 dbname2 = "hevt"+(c.get(Calendar.YEAR)%10);   
		 int min= c.get(Calendar.HOUR_OF_DAY)*60+c.get(Calendar.MINUTE);
		// logger.warn(min);//, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);//
	  	int vv = -2;
		if (map!=null)
		 {
			 if (key.indexOf("ai")>0){
					 down = map.get("LOWERLIMIT").toString();
					 up = map.get("UPPERLIMIT").toString();
					 rtuno = map.get("RTUNO").toString();
					 sn = map.get("SN").toString();
					 //logger.error(s);
				    //logger.error(luaStr);
				    //logger.error(map.get("LOWERLIMIT").toString());
					// logger.warn(map);
			     	vv =  checkupdown(vals,down,up,Integer.parseInt(map.get("CHGTIME").toString())); 
				    if (vv!=-2) 
				   	 {
				    	 //logger.warn(map);
				    	 //logger.warn(msg_author);
				   	   try
				   	   {
				   		 
						
				   	     add_red("INSERT INTO "+dbname+" (ymd,hms,ch,xh,zt,val) values ("+df.format(new Date())+","+df2.format(new Date())+","+rtuno+","+sn+","+vv+","+vals+")");    
				   	    //chgtime 字段用来存储当前遥测状态
				   	     add_red("UPDATE prtuana SET chgtime="+vv+" WHERE RTUNO="+rtuno+" AND SN="+sn);
				   	  	authormap = (HashMap<String,Object>)msg_author.get(map.get("deviceno").toString());
				   	  	logger.warn(authormap);
				   	    if (authormap!=null&&(min>Integer.parseInt(authormap.get("msg_st").toString()))&&(min<Integer.parseInt(authormap.get("msg_et").toString()))) 
				   	    {
				   	 	    msgah=authormap.get("author").toString();
				   	 	    mailah=authormap.get("author_mail").toString();
				   	    	String msg=query_red("select concat(a.pro_name,b.name,c.roomname,d.unitnm,e.name) msg from project_list a,prtu b,room c,dev_author d,prtuana e where a.pro_id=b.domain and b.rtuno=c.rtuno and c.roomno = d.roomno and d.deviceno=e.deviceno  and e.rtuno="+rtuno+" and e.sn="+sn);
				   	    	
			   	    		msg="【聆风智控】"+df3.format(new Date())+" "+msg;
			   	    		switch (vv)
			   	    		{
		   	    			case -1:
		   	    				msg=msg+" 越下限。备注："+vals+"（"+down+"~"+up+"）";
		   	    				break;
		   	    			case 0:
		   	    				msg=msg+" 恢复正常。备注："+vals+"（"+down+"~"+up+"）";
		   	    				break;
		   	    			case 1:
		   	    				msg=msg+" 越上限。备注："+vals+"（"+down+"~"+up+"）";
		   	    				break;
		   	    			default:
		   	    				break;
		   	    		    }
			   	    		if (msgah!=null )
				   	    	{
				   	    		try
				   	    		{
					   	    		String s= Integer.toBinaryString(Integer.parseInt(msgah));
					   	    		char ss[]=s.toCharArray();
					   	    		for (int i=0;i<ss.length;i++){
					   	    			if (ss[i]=='1'){
					   	    				usermap=(HashMap<String,String>) msg_user.get(""+(i+1));
					   	    				if (usermap!=null)
					   	    				  mobs=mobs+","+usermap.get("phone").toString();
					   	    			}
					   	    		}
					   	    		logger.warn(mobs.substring(1)+"："+msg);
				   	    		}catch(Exception e){}
			   	    		
			   	    		sendmsg.sendmsg(mobs.substring(1),msg);
				   	    	}
			   	    		if (mailah!=null )
				   	    	{
			   	    			HashMap<String, String> umap=new HashMap<String, String>();
				   	    		try
				   	    		{
				   	    			String s= Integer.toBinaryString(Integer.parseInt(mailah));
				   	    			char tt[]=s.toCharArray();
					   	    		for (int i=0;i<tt.length;i++){
					   	    			if (tt[i]=='1'){
					   	    				usermap=(HashMap<String,String>) msg_user.get(""+(i+1));
					   	    				if (usermap.get("email").toString()!=null)
					   	    				  umap.put(usermap.get("name").toString(), usermap.get("email").toString());//=mobs+","+usermap.get("email").toString();
					   	    			}
					   	    		}
				   	    	
				   	    		}catch(Exception e){}
				   	    	    emailUtil  sendmail = new emailUtil();
				   	    		logger.warn(sendmail.emailSend("系统信息", msg, umap)+":"+umap.toString());
				   	    		//sendmsg.sendmsg(mobs.substring(1),msg);
					   	    }	
				   	    	
				   	    	
				   	    	
				   	    	
				   	    }
				   	     
				   	    // logger.warn("save hevtyc:"+df.format(new Date())+","+df2.format(new Date())+","+rtuno+","+sn+","+vv+","+vals);
				   	   //updownstat.put(s, ""+vv);
				   	   ((HashMap<String,String>) objana.get(key)).put("CHGTIME", ""+vv);
				   	   } 
				   	   catch (Exception e) {
								e.printStackTrace();
					   }
				   	 }
		     }
			 if (key.indexOf("di")>0){
				    
			   	 //map =(Map) objdig.get(s);
			   	//logger.warn(map.toString());
			   	//logger.warn(vals);
				 mobs="";
			   	 rtuno = map.get("RTUNO").toString();
			   	 sn = map.get("SN").toString();
			   	 up = map.get("TYPE").toString();
			        vv =  checkevt(vals,Integer.parseInt(map.get("CHGTIME").toString())); 
			        if (map.get("CHGTIME").toString()!="-1" && vv!=0) 
			       	 {
			       	   try
			       	   {
			       	
			       	   add_red("INSERT INTO "+dbname2+" (ymd,hms,ch,xh,event,zt,ms) values ("+df.format(new Date())+","+df2.format(new Date())+","+rtuno+","+sn+","+up+","+vals+",'')");    
			       	   add_red("UPDATE prtudig SET chgtime="+vals+" where RTUNO="+rtuno+" AND SN="+sn);    
			       	   
			       	  // logger.warn("save hevt:"+df.format(new Date())+","+df2.format(new Date())+","+rtuno+","+sn+","+vv+","+vals);
			       	  
			       	   } catch (Exception e) {
								e.printStackTrace();
							}
			       	 }
			        authormap = (HashMap<String,Object>)msg_author.get(map.get("deviceno").toString());
			   	  	logger.warn(authormap);
			   	    if (authormap!=null&&(min>Integer.parseInt(authormap.get("msg_st").toString()))&&(min<Integer.parseInt(authormap.get("msg_et").toString()))) 
			   	    {
			   	 	    msgah=authormap.get("author").toString();
			   	 	    mailah=authormap.get("author_mail").toString();
			   	    	String msg=query_red("select concat(a.pro_name,b.name,c.roomname,d.unitnm,e.name,f.e_info) msg from project_list a,prtu b,room c,dev_author d,prtudig e,etype_info f where a.pro_id=b.domain and b.rtuno=c.rtuno and c.roomno = d.roomno and d.deviceno=e.deviceno and e.type=f.e_type  and e.rtuno="+rtuno+" and e.sn="+sn+" and .f.e_zt="+vals);
			   	    	
		   	    		msg="【聆风智控】"+df3.format(new Date())+" "+msg;
		   	    		
		   	    		if (msgah!=null )
			   	    	{
			   	    		try
			   	    		{
				   	    		String s= Integer.toBinaryString(Integer.parseInt(msgah));
				   	    		char ss[]=s.toCharArray();
				   	    		for (int i=0;i<ss.length;i++){
				   	    			if (ss[i]=='1'){
				   	    				usermap=(HashMap<String,String>) msg_user.get(""+(i+1));
				   	    				if (usermap!=null)
				   	    				  mobs=mobs+","+usermap.get("phone").toString();
				   	    			}
				   	    		}
				   	    		logger.warn(mobs.substring(1)+"："+msg);
			   	    		}catch(Exception e){}
		   	    		
			   	    		try {
								sendmsg.sendmsg(mobs.substring(1),msg);
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
			   	    	}
		   	    		if (mailah!=null )
			   	    	{
		   	    			HashMap<String, String> umap=new HashMap<String, String>();
			   	    		try
			   	    		{
			   	    			String s= Integer.toBinaryString(Integer.parseInt(mailah));
			   	    			char tt[]=s.toCharArray();
				   	    		for (int i=0;i<tt.length;i++){
				   	    			if (tt[i]=='1'){
				   	    				usermap=(HashMap<String,String>) msg_user.get(""+(i+1));
				   	    				if (usermap.get("email").toString()!=null)
				   	    				  umap.put(usermap.get("name").toString(), usermap.get("email").toString());//=mobs+","+usermap.get("email").toString();
				   	    			}
				   	    		}
			   	    	
			   	    		}catch(Exception e){}
			   	    	    emailUtil  sendmail = new emailUtil();
			   	    		logger.warn(sendmail.emailSend("系统信息", msg, umap)+":"+umap.toString());
			   	    		//sendmsg.sendmsg(mobs.substring(1),msg);
				   	    }	
			   	    	
			   	    	
			   	    	
			   	    	
			   	    }
			        ((HashMap<String,String>) objana.get(key)).put("CHGTIME", ""+vals);
			      
			        //map.clear();
			        //map=null;
			    }	 
			 
			
	    //map.clear();
	    //map=null;
    } else
	 {
		 logger.error("redis_key do not match mysql_kkey:"+key+",请确认！！！");
	 }
	
  }
    @Override
    public void onPMessage(String pattern, String channel, String message) {

		String val = "0";
		String luaStr = null;

		channel = channel.split(":")[1];
    	//logger.warn(pattern+" - "+channel+" - "+message);
        if (channel.indexOf("expired")>=0) {
            try {
				Reader r = new InputStreamReader(LuaJob.class.getResourceAsStream(message));
				luaStr = CharStreams.toString(r);
				tjedis.eval(luaStr);

				logger.info("延时任务执行完成："+message);
            }
            catch (Exception  e)
            {logger.error("delay lua err："+e.toString()+" : "+message);}

            return;
        }
    	if (channel.indexOf("o")>=0) {
    		
    		//logger.warn(pattern+" - "+channel+" - "+message);
    		return;
    	}
    	  		

    	try {
    		val = tjedis.get(channel);
		} catch (Exception  e) {
			val = "0";
			logger.warn(channel+":"+e);
		}


		/**
		 * 通知更新,目前采用修改redis中的anaupdate,authorupdate,conditionupdate 三个键值的方法
		 * redis消息队列？
		 */
		if (channel.matches("anaupdate"))
			try {
				objana = loadPrtu();
				logger.warn("the anatable has been reloaded.");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
    	if (channel.matches("authorupdate"))
			try {
				 msg_user = loaduser();
				 msg_author = loadauthor();
				logger.warn("the anatable has been reloaded.");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
    	if (channel.matches("conditionupdate"))
			try {
				objcondition = loadCondition();
				logger.warn("the conditiontable has been reloaded.");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
    	if (channel.indexOf("ch_")>=0)
    	{
    	    try {
    	    	
        	if (!skt.getSockets().isEmpty()) skt.broadcast(skt.getSockets(), "{\""+channel+"\":"+val+"}");
			} catch (Exception e) {
				e.printStackTrace();
			}
    	    channel = channel.replace("_.value","");
    	   
    	    handleEvt(channel,val); 
    	    
    	    if (objcondition.containsKey(channel)){
    	    	List<Map<String, Object>> dobj =  new ArrayList<Map<String, Object>>();
	    	    try{
	    	    	dobj = (List<Map<String, Object>>)objcondition.get(channel);
	    	    	for (int i=0;i<dobj.size();i++){
	    	    		if (checkcondition(val,dobj.get(i).get("condition").toString())){
		        	    	Reader r = new InputStreamReader(ThreadSubscriber.class.getResourceAsStream(dobj.get(i).get("luaname").toString()));
				            luaStr = CharStreams.toString(r);
				            tjedis.eval(luaStr);
				            logger.warn("condition lua handled :"+channel+dobj.get(i).get("condition").toString());
		        	    }
	    	    	}
	        	    

	    	    	
	    	    }catch (Exception e) {
	    	    	logger.error("condition lua err:"+e.toString());
					e.printStackTrace();
				}
    	    }
    	    
    	}
    	
    	/*if (channel.indexOf("o")>=0)
    	{
    		
    		
    	String val = "0";
    	
    	try {
    		val = tjedis.get(channel);
		} catch (Exception  e) {
			val = "0";
		}
			
    	//logger.warn(channel+":"+val);
    	 try {
         	if (thesesion.isOpen())
         	
         	synchronized(thesesion){

         		thesesion.getBasicRemote().sendText("{\""+channel+"\":"+val+"}");

        	}
			} catch (IOException e) {
				logger.info(e.toString()+" ---onPMessage");
				e.printStackTrace();
			}
    	}*/
    }
//add other Unimplemented methods
}
